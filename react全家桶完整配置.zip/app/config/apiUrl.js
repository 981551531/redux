var apiUrl = {
    url: "https://news.baidu.com",
    nerType: "/news?tn=bdapibaiyue&t=getuserdata"
}
export default  apiUrl;